add([
  text(args.text),
  origin('center'),
  scale(4),
  pos(width()/2, height()/2)
])