add([
  text(args.score),
  origin('center'),
  scale(10),
  pos(width()/2, height()/2)
])